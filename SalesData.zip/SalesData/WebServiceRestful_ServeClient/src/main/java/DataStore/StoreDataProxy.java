package DataStore;

public class StoreDataProxy implements DataStore.StoreData {
  private String _endpoint = null;
  private DataStore.StoreData storeData = null;
  
  public StoreDataProxy() {
    _initStoreDataProxy();
  }
  
  public StoreDataProxy(String endpoint) {
    _endpoint = endpoint;
    _initStoreDataProxy();
  }
  
  private void _initStoreDataProxy() {
    try {
      storeData = (new DataStore.StoreDataServiceLocator()).getstoreData();
      if (storeData != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)storeData)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)storeData)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (storeData != null)
      ((javax.xml.rpc.Stub)storeData)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public DataStore.StoreData getStoreData() {
    if (storeData == null)
      _initStoreDataProxy();
    return storeData;
  }
  
  public void main(java.lang.String[] args) throws java.rmi.RemoteException{
    if (storeData == null)
      _initStoreDataProxy();
    storeData.main(args);
  }
  
  
}